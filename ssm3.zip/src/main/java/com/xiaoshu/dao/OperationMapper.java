package com.xiaoshu.dao;

import com.xiaoshu.base.dao.BaseMapper;
import com.xiaoshu.entity.Operation;

public interface OperationMapper extends BaseMapper<Operation> {
}