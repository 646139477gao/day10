package com.xiaoshu.dao;

import com.xiaoshu.base.dao.BaseMapper;
import com.xiaoshu.entity.Role;

public interface RoleMapper extends BaseMapper<Role> {
}